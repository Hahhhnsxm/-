#ifndef __SYS_H__
#define __SYS_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

void NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */
