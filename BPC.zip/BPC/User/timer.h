#ifndef __TIMER_H__
#define __TIMER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"
	
//void TIM2_Cap_Init(void);
void TIM2_IRQHandler(void);
void TIM2_Cap_Init(u16 arr,u16 psc);

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */
