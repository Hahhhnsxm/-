#ifndef __DELAY_H__
#define __DELAY_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"
	
void delay_init();
void delay_us();

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */
