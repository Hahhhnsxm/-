#ifndef __LCD_H__
#define __LCD_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"
void LCD_ShowNum();
int  LCD_Init();
void LCD_ShowString();
void LCD_ShowxNum();
#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */
