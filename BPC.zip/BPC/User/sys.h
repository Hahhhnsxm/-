#ifndef __SYS_H__
#define __SYS_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"


#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */
