#ifndef __LED_H
#define __LED_H

#ifdef __cplusplus
 extern "C" {
#endif 

#include "stm32f10x.h"

void LED_Init(void);
	 
#ifdef __cplusplus
}
#endif

#endif 
